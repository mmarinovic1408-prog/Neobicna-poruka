let tekstB = "b";
let tekstA = "a";
let tekstSredina = " ide na Mjesec ";
let tekstKad = "kad";

let brojNula = 0;
let logickaVrijednost = true;
let vrijednostNaN = (brojNula * Number(logickaVrijednost)) / brojNula; 

let rijecBanana = tekstB + tekstA + vrijednostNaN + tekstA; 
let rijecNankad = vrijednostNaN + tekstKad;                  

let sastavljenaPoruka = rijecBanana + tekstSredina + rijecNankad;
console.log("Sastavljena poruka: " + sastavljenaPoruka);

let zadaniString = "baNaNa ide na Mjesec NaNkad"; // samo za usporedbu
let rezultatUsporedbe = (sastavljenaPoruka === zadaniString);

console.log("Rezultat usporedbe: " + rezultatUsporedbe);

console.log("\n Ispis vrsta podataka pomoću typeof");
console.log("sastavljenaPoruka (" + sastavljenaPoruka + "): " + typeof sastavljenaPoruka);
console.log("rezultatUsporedbe (" + rezultatUsporedbe + "): " + typeof rezultatUsporedbe);

console.log("tekstB (" + tekstB + "): " + typeof tekstB);
console.log("tekstA (" + tekstA + "): " + typeof tekstA);
console.log("tekstSredina (" + tekstSredina + "): " + typeof tekstSredina);
console.log("tekstKad (" + tekstKad + "): " + typeof tekstKad);
console.log("brojNula (" + brojNula + "): " + typeof brojNula);
console.log("logickaVrijednost (" + logickaVrijednost + "): " + typeof logickaVrijednost);
console.log("vrijednostNaN (" + vrijednostNaN + "): " + typeof vrijednostNaN);
console.log("rijecBanana (" + rijecBanana + "): " + typeof rijecBanana);
console.log("rijecNankad (" + rijecNankad + "): " + typeof rijecNankad);